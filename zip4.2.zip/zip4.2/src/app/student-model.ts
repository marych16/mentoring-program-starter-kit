export interface StudentModel {
  id: string;
  name: string;
  surname: string;
  grades: number[];
  selected: boolean;
 }