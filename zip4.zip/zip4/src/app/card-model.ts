export interface CardModel {
    title: string;
    description: string;
    imgScr: string;
    buttonFull: string;
    buttonRem: string;
    width: string;
    buttonLD: string;
    }
